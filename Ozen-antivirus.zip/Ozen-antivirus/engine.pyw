import socket, threading, os, psutil, hashlib, time, winreg, shutil, math, sys
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# --- CONFIGURATION ---
QUARANTINE_DIR = r"C:\antivirus tool\quarantine"
DOWNLOADS_DIR = os.path.join(os.path.expanduser("~"), "Downloads")
REAL_TIME_ACTIVE = False
PARENT_PID = None
WATCHLIST = {}
SUSPICION_THRESHOLD = 5
IGNORED_SYSTEM_FILES = {"desktop.ini", "thumbs.db", "ntuser.dat"}

if not os.path.exists(QUARANTINE_DIR):
    os.makedirs(QUARANTINE_DIR)

# --- SECURITY UTILITIES ---
def calculate_entropy(file_path):
    """Measures randomness to detect encryption (Ransomware)."""
    filename = os.path.basename(file_path).lower()
    if filename in IGNORED_SYSTEM_FILES: return 0
    try:
        with open(file_path, 'rb') as f:
            data = f.read(1024 * 1024)
            if not data: return 0
            entropy = 0
            for x in range(256):
                p_x = float(data.count(x)) / len(data)
                if p_x > 0: entropy += - p_x * math.log(p_x, 2)
            return entropy
    except: return 0

def is_system_under_attack():
    """Checks if the PC is being spammed or a virus is active."""
    # 1. Check for 'Window Bombing' (Spamming 1000 ads/windows)
    window_count = 0
    for proc in psutil.process_iter(['name']):
        try:
            if proc.info['name'] in ["cmd.exe", "mshta.exe", "powershell.exe"]:
                window_count += 1
        except: continue
    if window_count > 20: return True

    # 2. Check if any process has high suspicion in our watchlist
    for score in WATCHLIST.values():
        if score >= SUSPICION_THRESHOLD: return True
    return False

# --- DEFENSE LEVELS ---
def handle_threat(p_name, file_path, level):
    if level == 1: return f"level1|{p_name}|Suspicious"
    
    if level == 2: # Suspend (Freeze)
        for proc in psutil.process_iter(['name']):
            if proc.info['name'] == p_name:
                try: proc.suspend()
                except: pass
        return f"level2|{p_name}|Process Frozen"

    if level == 3: # Kill & Quarantine
        for proc in psutil.process_iter(['name']):
            if proc.info['name'] == p_name:
                try: proc.kill()
                except: pass
        try:
            dest = os.path.join(QUARANTINE_DIR, os.path.basename(file_path) + ".vir")
            shutil.move(file_path, dest)
            return f"level3|{p_name}|Neutralized"
        except: return f"level3|{p_name}|Deleted"

# --- MAIN SCAN LOGIC ---
def scan_logic(file_path):
    filename = os.path.basename(file_path).lower()
    if filename in IGNORED_SYSTEM_FILES: return "clean"

    entropy = calculate_entropy(file_path)
    if entropy > 7.5: # Likely Ransomware Encryption
        return handle_threat("Unknown_Encoder", file_path, level=3)

    for proc in psutil.process_iter(['name', 'cpu_percent', 'io_counters']):
        try:
            p_name = proc.info['name']
            # Basic Resource Logic
            if proc.info['cpu_percent'] > 80.0:
                WATCHLIST[p_name] = WATCHLIST.get(p_name, 0) + 1
                if WATCHLIST[p_name] >= SUSPICION_THRESHOLD:
                    return handle_threat(p_name, file_path, level=2)
        except: continue
    return "clean"

# --- HEARTBEAT & SERVER ---
def heartbeat_monitor():
    """The 'Last Stand' logic: Only quit if the boss left and it's safe."""
    global PARENT_PID
    while True:
        time.sleep(3)
        if PARENT_PID and not psutil.pid_exists(PARENT_PID):
            if is_system_under_attack():
                # Virus is trying to kill the AV; Stay alive!
                continue 
            else:
                # Normal exit
                os._exit(0)

def handle_client(conn):
    global REAL_TIME_ACTIVE, PARENT_PID
    try:
        while True:
            data = conn.recv(2048)
            if not data: break
            msg = data.decode('utf-8').strip()
            
            if msg.startswith("register_pid|"):
                PARENT_PID = int(msg.split("|")[1])
                conn.sendall(b"pid_registered\n")
            elif msg == "ping": conn.sendall(b"pong\n")
            elif msg == "shutdown": os._exit(0)
            elif msg.startswith("scan|"):
                res = scan_logic(msg.split("|")[1])
                conn.sendall((res + "\n").encode())
            elif msg.startswith("set_realtime|"):
                REAL_TIME_ACTIVE = "on" in msg
                conn.sendall(b"status_updated\n")
    except: pass
    finally: conn.close()

def start_engine():
    threading.Thread(target=heartbeat_monitor, daemon=True).start()
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("127.0.0.1", 54321))
    s.listen(5)
    while True:
        conn, addr = s.accept()
        threading.Thread(target=handle_client, args=(conn,), daemon=True).start()

if __name__ == "__main__":
    start_engine()
